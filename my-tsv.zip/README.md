This is a [Figma Template](https://www.figma.com/design/NxGeqbjtbp2x5tiEce94ab/Usaybek?node-id=0-1&p=f&t=CN7Wk0oGl7ZhikZV-0) 


https://surl.li/lzklum
https://surl.li/rdorwp