export type ParamsProps ={
    params: {
      id: string;
    };
  }
  
  
  export interface childrenProps {
    children: React.ReactNode;
  }