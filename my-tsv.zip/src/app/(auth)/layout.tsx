import { childrenProps } from "@/types";


export default function AuthLayout({ children }: childrenProps) {
  return (
    <>
      {children}
    </>
  );
}
